$(document).ready(function () {

    //Facility Rating
    $('.information_container .starability-result').attr('data-rating', 3);

});